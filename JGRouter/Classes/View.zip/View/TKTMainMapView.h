//
//  TKTMainMapView.h
//  TKTBind
//
//  Created by 张少林 on 2020/2/11.
//  Copyright © 2020 Tikteam. All rights reserved.
//

NS_ASSUME_NONNULL_BEGIN

@interface TKTMainMapView : UIView
@property(nonatomic, copy, nullable)TKTEmptyCallback loveAvatarDidClick;

@property (nonatomic, assign) BOOL isLoveDestanceDetail;// 用来处理自己的大头针显示

-(BOOL)moveToMineCoordinate;
-(BOOL)moveToLoverCoordinate;
- (void)starAnimation;
@end

NS_ASSUME_NONNULL_END
