//
//  TKTMineAnnotationPulsingHaloLayer.h
//  TKTBind
//
//  Created by 张少林 on 2020/2/12.
//  Copyright © 2020 Tikteam. All rights reserved.
//

NS_ASSUME_NONNULL_BEGIN

@interface TKTMineAnnotationPulsingHaloLayer : CAReplicatorLayer

@property (nonatomic, assign) CGFloat radius;
@property (nonatomic, assign) CGFloat innerRadius;

-(void)start;

@end

NS_ASSUME_NONNULL_END
