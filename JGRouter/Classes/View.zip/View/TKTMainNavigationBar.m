//
//  TKTMainNavigationBar.m
//  TKTBind
//
//  Created by 张少林 on 2020/2/13.
//  Copyright © 2020 Tikteam. All rights reserved.
//

#import "TKTMainNavigationBar.h"
#import "TKTAppWindow.h"

@implementation TKTMainNavigationBar {
    CAGradientLayer *_backgroundLayer;
    UILabel *_titlaLable;
}

@synthesize settingsButton = _settingsButton;
@synthesize loveDetailButton = _loveDetailButton;

-(instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self _initViews];
    }
    return self;
}

-(void)layoutSubviews {
    [super layoutSubviews];
    
    const UIView *superview = self.superview;
    if (!superview) {
        return;
    }
    const CGFloat safeTop = self.tkt_safeAreaInsets.top;
    const CGFloat height = safeTop + 80;
    const CGFloat width = self.superview.width;
    
    self.frame = CGRectMake(0.0f, 0.0f, width, height);
    
    TKTDisableLayerAnimtionBegin;
    _backgroundLayer.frame = self.frame;
    TKTDisableLayerAnimtionEnd;
    
    [_titlaLable sizeToFit];
    _titlaLable.origin = CGPointMake((width - _titlaLable.width) * 0.5f, safeTop + 13.0f);
     
    const CGFloat settingsButtonWidth = 24.0f;
    const CGFloat settingsButtonHeight = 25.0f;
    _settingsButton.frame = CGRectMake(19.0f,
                                       _titlaLable.centerY - (settingsButtonHeight * 0.5f),
                                       settingsButtonWidth,
                                       settingsButtonHeight);
    
    _loveDetailButton.frame = CGRectMake(MMFITWIDTH(316),
                                       _titlaLable.centerY - (settingsButtonHeight * 0.5f),
                                       40.0f,
                                       40.0f);
    
    _settingsButton.hitsCoefficient = 1.5f;
    _loveDetailButton.hitsCoefficient = 1.5f;
}

#pragma mark - Private
-(void)_initViews {
    _backgroundLayer = [CAGradientLayer layer];
    _backgroundLayer.startPoint = CGPointMake(0.5, 0.31);
    _backgroundLayer.endPoint = CGPointMake(0.5, 1);
    _backgroundLayer.colors = @[TKTIDCGColor(#FFFFFF), TKTIDCGColor(#FFFFFF, 0.0f)];
    _backgroundLayer.locations = @[@(0), @(1.0f)];
    [self.layer addSublayer:_backgroundLayer];
    
    _titlaLable = UILabel.New;
    _titlaLable.font = TKTFontPingFangSC(Semibold, 20.0f);
    _titlaLable.textColor = TKTColor(#010101);
    _titlaLable.text = TKTString("App Name");
    [self addSubview:_titlaLable];
    
    _settingsButton = TKTBaseButton.New;
    _settingsButton.image = [TKTImage imageNamed:@"MainNavSettings"];
    [self addSubview:_settingsButton];

    _loveDetailButton = TKTBaseButton.New;
    _loveDetailButton.image = [TKTImage imageNamed:@"heart"];
    [self addSubview:_loveDetailButton];
  
}

@end

