//
//  TKTMainConnectedView.m
//  TKTBind
//
//  Created by 张少林 on 2020/2/15.
//  Copyright © 2020 Tikteam. All rights reserved.
//

#import "TKTMainConnectedView.h"
#import "TKTAvatarView.h"

static NSString *kTKTMainConnectedMineDefaultAvatarName = @"MainMineDefaultAvatar";
static NSString *kTKTMainConnectedLoverDefaultAvatarName = @"MainLoverDefaultAvatar";

@interface TKTMainConnectedView()
@property(nonatomic, strong, readonly)UIImageView *backgroundView;
@property(nonatomic, strong, readonly)TKTAvatarView *mineAvatarView;
@property(nonatomic, strong, readonly)TKTAvatarView *loverAvatarView;
@property(nonatomic, strong, readonly)UILabel *distabceLabel;
@property(nonatomic, strong, readonly)UILabel *distabceValueLabel;
@end

@implementation TKTMainConnectedView {
    UIImageView *_backgroundView;
    CGSize _tkt_intrinsicContentSize;
    CGFloat _avatarSize;
    CGFloat _avatarMargin;
}

@synthesize backgroundView = _backgroundView;
@synthesize mineAvatarView = _mineAvatarView;
@synthesize loverAvatarView = _loverAvatarView;
@synthesize distabceLabel = _distabceLabel;
@synthesize distabceValueLabel = _distabceValueLabel;

-(instancetype)init {
    if (self = [super init]) {
        self.clipsToBounds = NO;
        [self _initViewsInternal];
    }
    return self;
}

-(CGSize)intrinsicContentSize {
    return _tkt_intrinsicContentSize;
}

-(CGSize)sizeThatFits:(CGSize)size {
    return self.intrinsicContentSize;
}

-(void)layoutFrames {
    [super layoutFrames];
    TKTWidthReferenceSizeBegin {
        self.backgroundView.frame = self.bounds;
        
        [self.mineAvatarView sizeToFit];
        self.mineAvatarView.origin = CGPointMake(_avatarMargin, _avatarMargin);
        
        [self.loverAvatarView sizeToFit];
        self.loverAvatarView.origin = CGPointMake(self.width - _avatarMargin - _avatarSize, _avatarMargin);
        
        [self _layoutDistanceLabels];
    } TKTWidthReferenceSizeEnd
}

#pragma mark - Setters & Getters
-(void)setMineAvatarDidClick:(TKTEmptyCallback)mineAvatarDidClick {
    self.mineAvatarView.avatarDidClick = mineAvatarDidClick;
}

-(TKTEmptyCallback)mineAvatarDidClick {
    return self.mineAvatarView.avatarDidClick;
}

-(void)setLoverAvatarDidClick:(TKTEmptyCallback)loverAvatarDidClick {
    self.loverAvatarView.avatarDidClick = loverAvatarDidClick;
}

-(TKTEmptyCallback)loverAvatarDidClick {
    return self.loverAvatarView.avatarDidClick;
}

-(UIImageView *)backgroundView {
    if (!_backgroundView) {
        TKTWidthReferenceSizeBegin {
            UIImageView *backgroundView = UIImageView.New;
            backgroundView.contentMode = UIViewContentModeScaleAspectFill;
            backgroundView.image = [UIImage imageNamed:@"MainConnectedBackground"];
            backgroundView.layer.cornerRadius = TKTSize(36.0f);
            backgroundView.layer.shadowColor = TKTCGColor(#000000, 0.20f);
            backgroundView.layer.shadowOffset = CGSizeMake(0, TKTSize(2.0f));
            backgroundView.layer.shadowOpacity = 1.0f;
            backgroundView.layer.shadowRadius = TKTSize(10.0f);
            _backgroundView = backgroundView;
        } TKTWidthReferenceSizeEnd
    }
    return _backgroundView;
}

-(TKTAvatarView *)mineAvatarView {
    if (!_mineAvatarView) {
        _mineAvatarView = [self _createAvatarView];
        TKTWeakSelf
        [TKTKVObserveNew(TKTAccount.mineProfile, avatarURL) {
            TKTStrongSelf {
                [self _updateMineAvatar];
            }
        }];
        [self _updateMineAvatar];
    }
    return _mineAvatarView;
}

-(TKTAvatarView *)loverAvatarView {
    if (!_loverAvatarView) {
        _loverAvatarView = [self _createAvatarView];
        TKTWeakSelf
        [TKTKVObserveNew(TKTAccount.loverProfile, avatarURL) {
            TKTStrongSelf {
                [self _updateLoverAvatar];
            }
        }];
        [self _updateLoverAvatar];
    }
    return _loverAvatarView;
}

-(UILabel *)distabceLabel {
    if (!_distabceLabel) {
        _distabceLabel = [self _createDistanceLabel];
        TKTWeakSelf
        [TKTKVObserveNew(TKTAccount, loverDistance) {
            TKTStrongSelf {
                [self _updateLoverDistance];
            }
        }];
        
        [TKTKVObserveNew(TKTAccount, haveLover) {
            TKTStrongSelf {
                [self _updateLoverDistance];
            }
        }];
        
        [TKTKVObserveNew(TKTAccount, isLogin) {
            TKTStrongSelf {
                [self _updateLoverDistance];
            }
        }];
        
        [TKTKVObserveNew(TKTAccount.loverProfile, nickname) {
            TKTStrongSelf {
                [self _updateLoverDistance];
            }
        }];
    }
    return _distabceLabel;
}

-(UILabel *)distabceValueLabel {
    if (!_distabceValueLabel) {
        _distabceValueLabel = [self _createDistanceLabel];
    }
    return _distabceValueLabel;
}

#pragma mark - Private
-(void)_initViewsInternal {
    TKTWidthReferenceSizeBegin {
        const CGFloat width = TKTSize(306.0f);
        const CGFloat height = TKTSize(72.0f);
        _tkt_intrinsicContentSize = CGSizeMake(width, height);
        _avatarSize = TKTSize(62.0f);
        _avatarMargin = (height - _avatarSize) * 0.5f;
    } TKTWidthReferenceSizeEnd
    
    [self addSubview:self.backgroundView];
    [self addSubview:self.mineAvatarView];
    [self addSubview:self.loverAvatarView];
    [self addSubview:self.distabceLabel];
    [self addSubview:self.distabceValueLabel];
    
    [self _updateMineAvatar];
    [self _updateLoverAvatar];
    [self _updateLoverDistance];
}

-(TKTAvatarView *)_createAvatarView {
    TKTAvatarView *avatarView = TKTAvatarView.New;
    avatarView.avatarSize = _avatarSize;
    avatarView.coverView.backgroundColor = UIColor.clearColor;
    avatarView.clickable = YES;
    return avatarView;
}

-(void)_setAvatar:(NSString * _Nullable)avatarURL forAvatarView:(TKTAvatarView *)avatarView defaultAvatarName:(NSString *)avatarName {
    if (isEmptyString(avatarURL)) {
        avatarView.avatarImage = [TKTImage imageNamed:avatarName];
    } else {
        avatarView.avatarURL = avatarURL;
    }
}

-(void)_updateMineAvatar {
    [self _setAvatar:TKTAccount.mineProfile.avatarURL
       forAvatarView:_mineAvatarView
   defaultAvatarName:kTKTMainConnectedMineDefaultAvatarName];
}

-(void)_updateLoverAvatar {
    [self _setAvatar:TKTAccount.loverProfile.avatarURL
       forAvatarView:_loverAvatarView
   defaultAvatarName:kTKTMainConnectedLoverDefaultAvatarName];
}

-(void)_updateLoverDistance {
    if (!TKTAccount.isLogin) {
        _distabceLabel.hidden = YES;
        _distabceValueLabel.hidden = YES;
    } else if (!TKTAccount.haveLover) {
        _distabceLabel.hidden = NO;
        _distabceLabel.text = TKTString("Distance Unknown");
        _distabceValueLabel.hidden = YES;
    } else  {
        const NSString *distance = TKTAccount.loverDistance;
        const NSString *loverName = TKTAccount.loverProfile.nickname;
        const BOOL hasDistance = !isEmptyString(distance) && !isEmptyString(loverName);
        
        _distabceLabel.hidden = !hasDistance;
        _distabceValueLabel.hidden = !hasDistance;
        
        if (hasDistance) {
            _distabceLabel.text = TKTStringf("Distance to %@", loverName);
            _distabceValueLabel.text = distance.copy;
            [self _layoutDistanceLabels];
        }
    }
}

-(void)_layoutDistanceLabels {
    TKTWidthReferenceSizeBegin {
        [_distabceLabel sizeToFit];
        _distabceLabel.left = (self.width - _distabceLabel.width) * 0.5f;
        _distabceLabel.top = TKTSize(11.0f);
        
        [_distabceValueLabel sizeToFit];
        _distabceValueLabel.left = (self.width - _distabceValueLabel.width) * 0.5f;
        _distabceValueLabel.top = _distabceLabel.bottom + TKTSize(19.0f);
    } TKTWidthReferenceSizeEnd
}

-(UILabel *)_createDistanceLabel {
    UILabel *label = UILabel.New;
    TKTWidthReferenceSizeBegin {
        label.hidden = YES;
        label.font = TKTFontSFUIText(Thin, TKTFontSize(12.0f));
        label.textColor = TKTColor(#333333);
    } TKTWidthReferenceSizeEnd
    return label;
}

@end
