//
//  TKTMineAnnotationPulsingHaloLayer.m
//  TKTBind
//
//  Created by 张少林 on 2020/2/12.
//  Copyright © 2020 Tikteam. All rights reserved.
//

#import "TKTMineAnnotationPulsingHaloLayer.h"

static const NSTimeInterval animationDuration = 3.0;
static const NSTimeInterval pulseInterval = 0.0;
static const  CGFloat keyTimeForHalfOpacity = 0.2f;

TKTConstKey(kTKTMineAnnotationPulsingHaloLayerAnimKey);

@interface TKTMineAnnotationPulsingHaloLayer()<CAAnimationDelegate>

@end

@implementation TKTMineAnnotationPulsingHaloLayer {
    CALayer *_effect;
    CAShapeLayer *_effectMask;
    CAAnimationGroup *_animationGroup;
    
    // for resume
    CALayer *_prevSuperlayer;
    uint _prevLayerIndex;
    CAAnimation *_prevAnimation;
}

-(instancetype)init {
    if (self = [super init]) {
        _effect = CALayer.layer;
        _effect.contentsScale = TKTScreenScale;
        _effect.opacity = 0.0f;
        _effect.backgroundColor = TKTCGColor(#017BF9);
        [self addSublayer:_effect];
        
        _effectMask = CAShapeLayer.layer;
        _effectMask.contentsScale = TKTScreenScale;
        _effectMask.opaque = 0.0f;
        _effectMask.fillColor = UIColor.clearColor.CGColor;
        _effectMask.strokeColor = UIColor.whiteColor.CGColor;
        _effectMask.lineCap = kCALineCapRound;
        self.mask = _effectMask;

        self.repeatCount = INFINITY;
        self.instanceDelay  = 1.0;
        
        self.instanceCount = 1;
        self.instanceDelay = (animationDuration + pulseInterval) / self.instanceCount;
        
        [self _initNotifications];
    }
    return self;
}

-(void)dealloc {
    [NSNotificationCenter.defaultCenter removeObserver:self];
}

- (void)start {
    [self _setupAnimationGroup];
    [_effect addAnimation:_animationGroup forKey:kTKTMineAnnotationPulsingHaloLayerAnimKey];
}

#pragma mark - Setters & Getters
- (void)setRadius:(CGFloat)radius {
    _radius = radius;
    
    const CGFloat diameter = radius * 2.0f;
    
    TKTDisableLayerAnimtionBegin;
    _effect.bounds = CGRectMake(0, 0, diameter, diameter);
    _effect.cornerRadius = radius;
    TKTDisableLayerAnimtionEnd;
    
    [self _updateMask];
}

-(void)setInnerRadius:(CGFloat)innerRadius {
    _innerRadius = innerRadius;
    [self _updateMask];
}

- (void)setFrame:(CGRect)frame {
    [super setFrame:frame];
    _effect.frame = frame;
}

#pragma mark - Delegate: CAAnimationDelegate
- (void)animationDidStop:(CAAnimation *)anim finished:(BOOL)flag {
    if ([_effect.animationKeys count]) {
        [_effect removeAllAnimations];
    }
    [_effect removeFromSuperlayer];
    [self removeFromSuperlayer];
}

#pragma mark - Actions
-(void)_didEnterBackground {
    _prevSuperlayer = self.superlayer;
    if (_prevSuperlayer) {
        unsigned int layerIndex = 0;
        for (CALayer *aSublayer in self.superlayer.sublayers) {
            if (aSublayer == self) {
                _prevLayerIndex = layerIndex;
                break;
            }
            layerIndex++;
        }
    }
    _prevAnimation = [_effect animationForKey:kTKTMineAnnotationPulsingHaloLayerAnimKey];
}

-(void)_willEnterForeground {
    [self _resume];
}

#pragma mark - Private
-(void) _resume{
    [self addSublayer:_effect];
    [_prevSuperlayer insertSublayer:self atIndex:_prevLayerIndex];
    if (_prevAnimation) {
        [_effect addAnimation:_prevAnimation forKey:kTKTMineAnnotationPulsingHaloLayerAnimKey];
    }
}

-(void)_setupAnimationGroup {
    CAAnimationGroup *animationGroup = [CAAnimationGroup animation];
    animationGroup.duration = animationDuration + pulseInterval;
    animationGroup.repeatCount = self.repeatCount;
    
    CAMediaTimingFunction *defaultCurve = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionDefault];
    animationGroup.timingFunction = defaultCurve;
    
    
    CABasicAnimation *scaleAnimation = [CABasicAnimation animationWithKeyPath:@"transform.scale.xy"];
    scaleAnimation.fromValue = @(_innerRadius / _radius);
    scaleAnimation.toValue = @1.0;
    scaleAnimation.duration = animationDuration;
    
    CAKeyframeAnimation *opacityAnimation = [CAKeyframeAnimation animationWithKeyPath:@"opacity"];
    opacityAnimation.duration = animationDuration;
    
    opacityAnimation.values = @[@0.2f, @0.1f, @0.00f];
    opacityAnimation.keyTimes = @[@0, @(keyTimeForHalfOpacity), @1];
    
    NSArray *animations = @[scaleAnimation, opacityAnimation];
    
    animationGroup.animations = animations;
    
    _animationGroup = animationGroup;
    _animationGroup.delegate = self;
}

-(void)_initNotifications {
    const NSNotificationCenter *nc = NSNotificationCenter.defaultCenter;
    [nc addObserver:self
           selector:$(_didEnterBackground)
               name:UIApplicationDidEnterBackgroundNotification object:nil];
    
    [nc addObserver:self
           selector:$(_willEnterForeground)
               name:UIApplicationWillEnterForegroundNotification object:nil];
}

-(void)_updateMask {
    const CGFloat lineWidth = (self.radius - self.innerRadius) * 2.0f + 1.0f;
    const TKTRect frame = TKTRectFromCGRect(self.bounds);
    const UIBezierPath *bezierPath = [UIBezierPath bezierPathWithArcCenter:CGPointMake(frame.midX, frame.midY)
                                                              radius:self.radius
                                                          startAngle:0.0f
                                                            endAngle:M_PI * 2.0f
                                                           clockwise:YES];
    TKTDisableLayerAnimtionBegin;
    _effectMask.path = bezierPath.CGPath;
    _effectMask.lineWidth = lineWidth;
    TKTDisableLayerAnimtionEnd;
}

@end
