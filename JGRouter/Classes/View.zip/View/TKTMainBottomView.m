//
//  TKTMainBottomView.m
//  TKTBind
//
//  Created by 张少林 on 2020/2/15.
//  Copyright © 2020 Tikteam. All rights reserved.
//

#import "TKTMainBottomView.h"
#import "TKTBaseTextButton.h"
#import "TKTMainConnectedView.h"

@interface TKTMainBottomView()
@property(nonatomic, strong, readonly)TKTMainConnectedView *connectedView;
@property(nonatomic, strong, readonly)TKTBaseTextButton *loginButton;
@property(nonatomic, strong, readonly)TKTBaseTextButton *inviteLoverButton;

@end

@implementation TKTMainBottomView {
    CGFloat _bottomButtonVerticalSpace;
    CGFloat _bottomEmptyVerticalSpace;
}

@synthesize connectedView = _connectedView;
@synthesize loginButton = _loginButton;
@synthesize inviteLoverButton = _inviteLoverButton;

-(instancetype)init {
    if (self = [super init]) {
        [self _initViewsInternal];
    }
    return self;
}

-(CGSize)sizeThatFits:(CGSize)size {
    [_connectedView sizeToFit];
    CGFloat height = _connectedView.height;
    
    const BOOL bottomEmpty = TKTAccount.isLogin && TKTAccount.haveLover;
    
    if (!bottomEmpty) {
        height += _bottomButtonVerticalSpace;
    } else {
        height += _bottomEmptyVerticalSpace;
    }
    
    return CGSizeMake(TKTScreenWidth, height);
}

-(void)layoutFrames {
    [super layoutFrames];
    
    const TKTMainConnectedView *connectedView = self.connectedView;
    const UIView *loginButton = self.loginButton;
    const UIView *inviteLoverButton = self.inviteLoverButton;
    
    loginButton.hidden = TKTAccount.isLogin;
    
    BOOL haveLover = TKTAccount.haveLover;
    inviteLoverButton.hidden = !loginButton.hidden || haveLover;
    
    TKTWidthReferenceSizeBegin {
        [connectedView sizeToFit];
        connectedView.origin = CGPointMake((self.width - _connectedView.width) * 0.5f, 0.0f);
        
        if (!loginButton.hidden) {
            loginButton.top = connectedView.bottom + TKTSize(25.0f);
            loginButton.left = (self.width - loginButton.width) * 0.5f;
        }
        
        if (!inviteLoverButton.hidden) {
            inviteLoverButton.top = connectedView.bottom + TKTSize(15.0f);
            inviteLoverButton.left = (self.width - inviteLoverButton.width) * 0.5f;
        }
        
    } TKTWidthReferenceSizeEnd
}

#pragma mark - Setters & Getters
-(void)setMineAvatarDidClick:(TKTEmptyCallback)mineAvatarDidClick {
    self.connectedView.mineAvatarDidClick = mineAvatarDidClick;
}

-(TKTEmptyCallback)mineAvatarDidClick {
    return self.connectedView.mineAvatarDidClick;
}

-(void)setLoverAvatarDidClick:(TKTEmptyCallback)loverAvatarDidClick {
    self.connectedView.loverAvatarDidClick = loverAvatarDidClick;
}

-(TKTEmptyCallback)loverAvatarDidClick {
    return self.connectedView.loverAvatarDidClick;
}

-(TKTBaseTextButton *)loginButton {
    if (!_loginButton) {
        TKTWidthReferenceSizeBegin {
            
            const CGFloat width = TKTSize(242.0f);
            const CGFloat height = TKTSize(50.0f);
            
            TKTBaseTextButton *loginButton = TKTBaseTextButton.TKTView(width, height);
            [loginButton TKTAddClickTarget(_loginDidClick)];
            loginButton.cornerRadius = TKTSize(16.0f);
            loginButton.font = TKTFontPingFangSC(Semibold, TKTFontSize(12.0f));
            loginButton.textColor = UIColor.whiteColor;
            loginButton.clipsToBounds = NO;
            loginButton.text = TKTString("Login/Register");
            loginButton.layer.backgroundColor = TKTCGColor(#007BFA);
            loginButton.layer.shadowColor = TKTCGColor(#007BFA, 0.36f);
            loginButton.layer.shadowOffset = CGSizeMake(0, TKTSize(8.0f));
            loginButton.layer.shadowOpacity = 1;
            loginButton.layer.shadowRadius = TKTSize(12.0f);
            _loginButton = loginButton;
        } TKTWidthReferenceSizeEnd
    }
    return _loginButton;
}

-(TKTBaseTextButton *)inviteLoverButton {
    if (!_inviteLoverButton) {
        TKTWidthReferenceSizeBegin {
            
            const CGFloat width = TKTSize(310.0f);
            const CGFloat height = TKTSize(74.0f);
            
            TKTBaseTextButton *inviteLoverButton = TKTBaseTextButton.TKTView(width, height);
            [inviteLoverButton TKTAddClickTarget(_inviteLoverDidClick)];
            inviteLoverButton.font = TKTFontPingFangSC(Medium, TKTFontSize(18.0f));
            inviteLoverButton.textColor = UIColor.whiteColor;
            inviteLoverButton.image = [TKTImage imageNamed:@"MainBottomInviteLoverBackground"];
            inviteLoverButton.clipsToBounds = NO;
            inviteLoverButton.text = TKTString("Main - Bottom Invite Lover Button");
            inviteLoverButton.layer.shadowColor = TKTCGColor(#000000, 0.10f);
            inviteLoverButton.layer.shadowOffset = CGSizeMake(0, TKTSize(4.0f));
            inviteLoverButton.layer.shadowOpacity = 1;
            inviteLoverButton.layer.shadowRadius = TKTSize(14.0f);
            _inviteLoverButton = inviteLoverButton;
        } TKTWidthReferenceSizeEnd
    }
    return _inviteLoverButton;
}

- (TKTMainConnectedView *)connectedView {
    if (!_connectedView) {
        _connectedView = TKTMainConnectedView.New;
    }
    return _connectedView;
}

#pragma mark - Actions
-(void)_loginDidClick {
    const TKTEmptyCallback callback = self.loginDidClick;
    if (callback) {
        callback();
    }
}

-(void)_inviteLoverDidClick {
    const TKTEmptyCallback callback = self.inviteLoverDidClick;
    if (callback) {
        callback();
    }
}

#pragma mark - Private
-(void)_initViewsInternal {
    TKTWidthReferenceSizeBegin {
        _bottomButtonVerticalSpace = TKTSize(107.0f);
        _bottomEmptyVerticalSpace = TKTSize(24.0f);
    } TKTWidthReferenceSizeEnd
    
    [self addSubview:self.connectedView];
    [self addSubview:self.loginButton];
    [self addSubview:self.inviteLoverButton];
}

@end
