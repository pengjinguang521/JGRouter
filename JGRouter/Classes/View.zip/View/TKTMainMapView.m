//
//  TKTMainMapView.m
//  TKTBind
//
//  Created by 张少林 on 2020/2/11.
//  Copyright © 2020 Tikteam. All rights reserved.
//

#import "TKTMainMapView.h"
#import <AMapFoundationKit/AMapFoundationKit.h>
#import <MAMapKit/MAMapKit.h>

#import <AMapSearchKit/AMapSearchKit.h>

#import "TKTLoverMapAnnotationView.h"
#import "TKTMineMapAnnotationView.h"
#import "TKTAccountService.h"
#import "TKTLocationService.h"
#import "TKTAppWindow.h"

TKTConstKey(kLoverMapAnnotationReuseIdentifier);
TKTConstKey(kMineMapAnnotationReuseIdentifier);

#define kTKTMainMapDefaultZoomLevel 19.0f
#define kTKTMainMapMinMoveDegreeGap 0.005

@interface TKTMainMapView()<MAMapViewDelegate, AMapSearchDelegate>

@property (nonatomic, strong) AMapSearchAPI *search; // 地图规划路线搜索
@property (nonatomic, strong) MAPolyline *polyline; // 划线

@end

@implementation TKTMainMapView {
    MAMapView *_mapView;
    
    MAPointAnnotation *_loverPointAnnotation;
    MAPointAnnotation *_minePointAnnotation;
    
    TKTLoverMapAnnotationView *_loverMapAnnotationView;
    TKTMineMapAnnotationView *_mineMapAnnotationView;
    // 如果是恋爱距离详情页 这边自己的大头针要显示出来
    TKTLoverMapAnnotationView *_mineMapAnnotationLoveDestanceView;
    
    BOOL _needZoomFocusAfterMoved;
}

-(instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self _initViews];
        [self addSubview:_mapView];
        _needZoomFocusAfterMoved = NO;
    }
    return self;
}

-(BOOL)moveToMineCoordinate {
    const BOOL result = [self _moveToCoordinate:TKTAccount.mineProfile.coordinate];
//    if (result) {
//        TKTWeakSelf
//        tkt_dispatch_main_delayed(0.4f, ^{
//            TKTStrongSelf {
//                [self->_loverMapAnnotationView doActiveAnimation];
//            }
//        });
//    }
    return result;
}

-(BOOL)moveToLoverCoordinate {
    return [self _moveToCoordinate:TKTAccount.loverProfile.coordinate];
}

- (void)starAnimation{
    if (_mineMapAnnotationView) {
        [_mineMapAnnotationView start];
    }
}

#pragma mark - Delegate: MAMapViewDelegate
- (MAAnnotationView *)mapView:(MAMapView *)mapView viewForAnnotation:(id<MAAnnotation>)annotation {
    if (annotation == _loverPointAnnotation ) {
        return _loverMapAnnotationView;
    } else if (annotation == _minePointAnnotation ) {
        
        if (self.isLoveDestanceDetail) {
            return _mineMapAnnotationLoveDestanceView;
        }
        
        TKTMineMapAnnotationView *annotationView = (TKTMineMapAnnotationView *)[mapView dequeueReusableAnnotationViewWithIdentifier:kMineMapAnnotationReuseIdentifier];
        if (annotationView == nil) {
            annotationView = [[TKTMineMapAnnotationView alloc] initWithAnnotation:annotation
                                                                  reuseIdentifier:kMineMapAnnotationReuseIdentifier];
        }
        _mineMapAnnotationView = annotationView;
        
        [self _updateMineHeading];
        return _mineMapAnnotationView;
    }
    return nil;
}

- (void)mapViewRegionChanged:(MAMapView *)mapView{
    [self _updateMineHeading];
}

#pragma mark - Private
-(void)_initViews {
    MAMapView *mapView = [[MAMapView alloc] initWithFrame:self.bounds];
    mapView.mapType = MAMapTypeStandard;
    mapView.zoomEnabled = YES;
    mapView.rotateEnabled = YES;
    mapView.showsBuildings = YES;
    mapView.showsCompass = NO;
    mapView.zoomingInPivotsAroundAnchorPoint = YES;
    mapView.touchPOIEnabled = NO;
    mapView.cameraDegree = 20.0f;
    mapView.rotateCameraEnabled = NO;
    mapView.showsScale = NO;
    mapView.delegate = self;
    mapView.zoomLevel = kTKTMainMapDefaultZoomLevel;
    
    if (TKTAppWindow.shared.tt_safeAreaInsets.bottom > 0) {
        const CGPoint logoCenter = mapView.logoCenter;
        mapView.logoCenter = CGPointMake(logoCenter.x + 20.0f, logoCenter.y);
    }
    
    _loverPointAnnotation = MAPointAnnotation.New;
    _loverPointAnnotation.lockedToScreen = NO;
    _loverPointAnnotation.coordinate = CLLocationCoordinate2DMake(39.989631, 116.481018);
    
    _loverMapAnnotationView = [[TKTLoverMapAnnotationView alloc] initWithAnnotation:_loverPointAnnotation
                                                                    reuseIdentifier:kLoverMapAnnotationReuseIdentifier];
    
    TKTWeakSelf
    _loverMapAnnotationView.avatarDidClick = ^{
        TKTStrongSelf {
            if (self.loveAvatarDidClick) {
                self.loveAvatarDidClick();
            }
            [self moveToLoverCoordinate];
        }
    };
    
    _minePointAnnotation = MAPointAnnotation.New;
    _minePointAnnotation.lockedToScreen = NO;
    
    [self loveDestanceDetailMineView];
    
    _mapView = mapView;
    
    [self _updateMineCoordinate];
    [self _updateLoverCoordinate];
    
    [TKTKVObserveNew(TKTAccount.mineProfile, coordinate) {
        TKTStrongSelf {
            [self _updateMineCoordinate];
        }
    }];
    
    [TKTKVObserveNew(TKTAccount.mineProfile, gender) {
        TKTStrongSelf {
            [self _updateMapStyle];
        }
    }];
    
    [TKTKVObserveNew(TKTAccount.loverProfile, coordinate) {
        TKTStrongSelf {
            [self _updateLoverCoordinate];
        }
    }];
    
    [TKTKVObserveNew(TKTLocationService.shared, heading) {
        TKTStrongSelf {
            [self _updateMineHeading];
        }
    }];
    [self _updateMapStyle];
}

- (void)loveDestanceDetailMineView {
    _mineMapAnnotationLoveDestanceView = [[TKTLoverMapAnnotationView alloc] initWithAnnotation:_minePointAnnotation
        reuseIdentifier:kMineMapAnnotationReuseIdentifier];
    TKTWeakSelf
    _mineMapAnnotationLoveDestanceView.avatarDidClick = ^{
        TKTStrongSelf {
            [self moveToMineCoordinate];
        }
    };
}

- (void)setIsLoveDestanceDetail:(BOOL)isLoveDestanceDetail {
    _isLoveDestanceDetail = isLoveDestanceDetail;
    if (_isLoveDestanceDetail == YES) {
        [self initMapSearchKit];
    }
}

#pragma mark - mapSearchKit 添加驾车距离规划 地图划线代码
- (void)initMapSearchKit {
    self.search = [[AMapSearchAPI alloc] init];
    self.search.delegate = self;
    AMapDrivingRouteSearchRequest *navi = [[AMapDrivingRouteSearchRequest alloc] init];
    navi.requireExtension = YES;
    navi.strategy = 5;
    /* 出发点. */
    navi.origin = [AMapGeoPoint locationWithLatitude:TKTAccount.mineProfile.coordinate.latitude
                                           longitude:TKTAccount.mineProfile.coordinate.longitude];
    /* 目的地. */
    navi.destination = [AMapGeoPoint locationWithLatitude:TKTAccount.loverProfile.coordinate.latitude
                                                longitude:TKTAccount.loverProfile.coordinate.longitude];
    [self.search AMapDrivingRouteSearch:navi];
    
    // 这边设置两个点都在地图中
    
    TKTUserCoordinateModel *modelMine = TKTAccount.mineProfile.coordinate;
    TKTUserCoordinateModel *modelLover = TKTAccount.loverProfile.coordinate;
    
    NSMutableArray *mutArr = [NSMutableArray array];
    if (modelMine) {
        [mutArr addObject:modelMine];
    }
    if (modelLover) {
        [mutArr addObject:modelLover];
    }
    [_mapView showAnnotations:mutArr edgePadding:UIEdgeInsetsMake(90, 50, 20, 50) animated:YES];

    
    
}

#pragma mark - AMapSearchDelegate
- (void)onRouteSearchDone:(AMapRouteSearchBaseRequest *)request response:(AMapRouteSearchResponse *)response{
    if (response.route == nil){
        return;
    }
    
    if (response.count > 0){
        //直接取第一个方案
        AMapPath *path = response.route.paths[0];
        //移除旧折线对象
        [_mapView removeOverlay:_polyline];
        //构造折线对象
        _polyline = [self polylinesForPath:path];
        //添加新的遮盖，然后会触发代理方法(- (MAOverlayRenderer *)mapView:(MAMapView *)mapView rendererForOverlay:(id<MAOverlay>)overlay)进行绘制
        // 存储价格
        [[NSUserDefaults standardUserDefaults] setFloat:response.route.taxiCost forKey:TKTAMapSearchPrice];
        [[NSUserDefaults standardUserDefaults] synchronize];
        [_mapView addOverlay:_polyline];
    }
}
//路线解析
- (MAPolyline *)polylinesForPath:(AMapPath *)path{
    if (path == nil || path.steps.count == 0){
        return nil;
    }
    NSMutableString *polylineMutableString = [@"" mutableCopy];
    for (AMapStep *step in path.steps) {
        [polylineMutableString appendFormat:@"%@;",step.polyline];
    }
    
    NSUInteger count = 0;
    CLLocationCoordinate2D *coordinates = [self coordinatesForString:polylineMutableString
                                                     coordinateCount:&count
                                                          parseToken:@";"];
    
    MAPolyline *polyline = [MAPolyline polylineWithCoordinates:coordinates count:count];
    
    free(coordinates), coordinates = NULL;
    return polyline;
}

//解析经纬度
- (CLLocationCoordinate2D *)coordinatesForString:(NSString *)string
                                 coordinateCount:(NSUInteger *)coordinateCount
                                      parseToken:(NSString *)token{
    if (string == nil){
        return NULL;
    }
    
    if (token == nil){
        token = @",";
    }
    
    NSString *str = @"";
    if (![token isEqualToString:@","]){
        str = [string stringByReplacingOccurrencesOfString:token withString:@","];
    }else{
        str = [NSString stringWithString:string];
    }
    
    NSArray *components = [str componentsSeparatedByString:@","];
    NSUInteger count = [components count] / 2;
    if (coordinateCount != NULL){
        *coordinateCount = count;
    }
    CLLocationCoordinate2D *coordinates = (CLLocationCoordinate2D*)malloc(count * sizeof(CLLocationCoordinate2D));
    
    for (int i = 0; i < count; i++){
        coordinates[i].longitude = [[components objectAtIndex:2 * i]     doubleValue];
        coordinates[i].latitude  = [[components objectAtIndex:2 * i + 1] doubleValue];
    }
    return coordinates;
}
- (MAOverlayRenderer *)mapView:(MAMapView *)mapView rendererForOverlay:(id<MAOverlay>)overlay {
    if ([overlay isKindOfClass:[MAPolyline class]]){
        MAPolyline *polyline = (MAPolyline *)overlay;
        MAPolylineRenderer *polylineRenderer = [[MAPolylineRenderer alloc] initWithPolyline:polyline];
        //添加纹理图片
        //若设置了纹理图片，设置线颜色、连接类型和端点类型将无效。
        UIImage *lineImage = [UIImage imageNamed:@"wenli1.jpg"];
        polylineRenderer.strokeImage  = lineImage;
        polylineRenderer.lineWidth    = 10.f;
        return polylineRenderer;
    }
    return nil;
}



-(void)_updateMineCoordinate{
    //[_mineMapAnnotationView start];
    [self _updateAnnotation:_minePointAnnotation withCoordinate:TKTAccount.mineProfile.coordinate];
}

-(void)_updateLoverCoordinate {
    [self _updateAnnotation:_loverPointAnnotation withCoordinate:TKTAccount.loverProfile.coordinate];
    _loverMapAnnotationView.avatarURL = TKTAccount.loverProfile.avatarURL;
    // 设置自己的头像
    _mineMapAnnotationLoveDestanceView.avatarURL = TKTAccount.mineProfile.avatarURL;
}

-(void)_updateAnnotation:(MAPointAnnotation *)annotation withCoordinate:(TKTUserCoordinateModel *)coordinate {
    if (coordinate && [coordinate isKindOfClass:TKTUserCoordinateModel.class]) {
        if (![_mapView.annotations containsObject:annotation]) {
            [_mapView addAnnotation:annotation];
        }
        annotation.coordinate = coordinate.coordinate;
    }else {
        if ([annotation isEqual:_loverPointAnnotation]) {
            [_mapView removeAnnotation:annotation];
        }
    }
}

-(BOOL)_moveToCoordinate:(TKTUserCoordinateModel *)coordinate {
    if (coordinate && [coordinate isKindOfClass:TKTUserCoordinateModel.class]) {
        const CLLocationCoordinate2D centerCoordinate = _mapView.centerCoordinate;
        if (ABS(centerCoordinate.latitude - coordinate.latitude) < kTKTMainMapMinMoveDegreeGap &&
            (centerCoordinate.longitude - coordinate.longitude) < kTKTMainMapMinMoveDegreeGap) {
            [_mapView setCenterCoordinate:coordinate.coordinate animated:YES];
            [self _focusByZoomimg];
        } else {
            [_mapView setCenterCoordinate:coordinate.coordinate animated:YES];
            _needZoomFocusAfterMoved = YES;
        }
        
        return YES;
    }
    return NO;
}

-(void)_updateMineHeading {
    const CLHeading *heading = TKTLocationService.shared.heading;
    _mineMapAnnotationView.isSightHidden = !heading;
    if (!_mineMapAnnotationView.isSightHidden) {
        
        _mineMapAnnotationView.sightAngle = heading.trueHeading - _mapView.rotationDegree;
    }
}

-(void)_updateMapStyle {
    MAMapCustomStyleOptions *options = MAMapCustomStyleOptions.New;
    if (TKTAccount.mineProfile.gender == kTKTUserGenderBoy) {
        options.styleId = TKT_AMAP_BOY_STYLE_ID;
    } else {
        options.styleId = TKT_AMAP_GIRL_STYLE_ID;
    }
    [_mapView setCustomMapStyleOptions:options];
    [_mapView setCustomMapStyleEnabled:YES];
}

-(void)_focusByZoomimg {
    [_mapView setZoomLevel:kTKTMainMapDefaultZoomLevel animated:YES];
}

@end
