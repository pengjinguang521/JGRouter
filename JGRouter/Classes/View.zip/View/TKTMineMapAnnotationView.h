//
//  TKTMineMapAnnotationView.h
//  TKTBind
//
//  Created by 张少林 on 2020/2/12.
//  Copyright © 2020 Tikteam. All rights reserved.
//

#import <MAMapKit/MAMapKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TKTMineMapAnnotationView : MAAnnotationView

@property(nonatomic, assign, readwrite)CGFloat sightAngle; // 0 ~ 360
@property(nonatomic, assign, readwrite, setter=setSightHidden:)BOOL isSightHidden;
- (void)start;
@end

NS_ASSUME_NONNULL_END
