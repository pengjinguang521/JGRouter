//
//  TKTMineMapAnnotationView.m
//  TKTBind
//
//  Created by 张少林 on 2020/2/12.
//  Copyright © 2020 Tikteam. All rights reserved.
//

#import "TKTMineMapAnnotationView.h"
#import "TKTMineAnnotationPulsingHaloLayer.h"

@interface TKTMineMapAnnotationView ()

@end


@implementation TKTMineMapAnnotationView {
    UIImageView *_sightView;
    CGFloat _backgroundSize;
    CGFloat _iconSize ;
}

-(id)initWithAnnotation:(id<MAAnnotation>)annotation reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithAnnotation:annotation reuseIdentifier:reuseIdentifier]) {
        self.canShowCallout = NO;
        [self _initViews];
    }
    return self;
}

#pragma mark - Setters & Getters
-(void)setSightAngle:(CGFloat)sightAngle {
    if (sightAngle < 0.0f) {
        sightAngle += 360.0f;
    } else if (sightAngle > 360.0f) {
        sightAngle -= 360.0f;
    }
    _sightAngle = sightAngle;
    const TKTRect sightBounds = _sightView.tkt_bounds;
    _sightView.transform = TKTAffineTransformMakeRotateAroundPoint(sightBounds.midX, sightBounds.midY,
                                                                   sightBounds.midX, sightBounds.maxY,
                                                                   sightAngle * M_PI / 180.0f);
}

- (void)setSightHidden:(BOOL)isSightHidden {
    _sightView.hidden = isSightHidden;
}

-(BOOL)isSightHidden {
    return _sightView.isHidden;
}

#pragma mark - Private
-(void)_initViews {
    self.image = [UIImage imageNamed:@"MapMineAnnotationIcon"];
    TKTWidthReferenceSizeBegin {
        _backgroundSize = TKTSize(70.0f);
        _iconSize = TKTSize(32.0f);
        const CGFloat iconMargin = (_backgroundSize - _iconSize) * 0.5f;
        
        self.size = CGSizeMake(_backgroundSize, _backgroundSize);
        self.imageView.contentMode = UIViewContentModeScaleAspectFit;
        self.imageView.frame = CGRectMake(iconMargin, iconMargin, _iconSize, _iconSize);
        
        [self start];
        
        const CGFloat sightWidth = TKTSize(30.0f);
        const CGFloat sightHeight = TKTSize(104.0f);
        
        const CGFloat anchorX = self.imageView.centerX;
        const CGFloat anchorY = self.imageView.centerY;
        
        const CGFloat x = anchorX - sightWidth * 0.5f;
        const CGFloat y = anchorY - sightHeight;
        
        UIImageView *sightView = UIImageView.TKTView(x, y, sightWidth, sightHeight);
        sightView.hidden = YES;
        sightView.contentMode = UIViewContentModeScaleAspectFill;
        sightView.image = [UIImage imageNamed:@"MapMineSight"];
        [self insertSubview:sightView atIndex:0];
        _sightView = sightView;
    } TKTWidthReferenceSizeEnd
}

- (void)start{
    TKTWidthReferenceSizeBegin {
        const CGFloat halfBackgroundSize = _backgroundSize * 0.5f;
        
        TKTMineAnnotationPulsingHaloLayer *halo =TKTMineAnnotationPulsingHaloLayer.layer;
        halo.radius = halfBackgroundSize;
        halo.innerRadius = _iconSize * 0.5f;
        halo.position = CGPointMake(halfBackgroundSize, halfBackgroundSize);
        [self.layer addSublayer:halo];
        [halo start];
    } TKTWidthReferenceSizeEnd
}

@end
