//
//  TKTMainNavigationBar.h
//  TKTBind
//
//  Created by 张少林 on 2020/2/13.
//  Copyright © 2020 Tikteam. All rights reserved.
//

#import "TKTBaseButton.h"

NS_ASSUME_NONNULL_BEGIN

@interface TKTMainNavigationBar : UIView

@property(nonatomic, strong, readonly)TKTBaseButton *settingsButton;

@property(nonatomic, strong, readonly)TKTBaseButton *loveDetailButton;

@end

NS_ASSUME_NONNULL_END
