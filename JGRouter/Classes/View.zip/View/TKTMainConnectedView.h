//
//  TKTMainConnectedView.h
//  TKTBind
//
//  Created by 张少林 on 2020/2/15.
//  Copyright © 2020 Tikteam. All rights reserved.
//

NS_ASSUME_NONNULL_BEGIN

@interface TKTMainConnectedView : UIView

@property(nonatomic, copy, nullable)TKTEmptyCallback mineAvatarDidClick;
@property(nonatomic, copy, nullable)TKTEmptyCallback loverAvatarDidClick;

@end

NS_ASSUME_NONNULL_END
