//
//  TKTLoverMapAnnotationView.m
//  TKTBind
//
//  Created by 张少林 on 2020/2/12.
//  Copyright © 2020 Tikteam. All rights reserved.
//

#import "TKTLoverMapAnnotationView.h"
#import "TKTAvatarView.h"

@implementation TKTLoverMapAnnotationView {
    TKTAvatarView *_avatarView;
}

-(id)initWithAnnotation:(id<MAAnnotation>)annotation reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithAnnotation:annotation reuseIdentifier:reuseIdentifier]) {
        self.canShowCallout = NO;
        self.backgroundColor = UIColor.clearColor;
        [self _initViews];
    }
    return self;
}

//-(void)doActiveAnimation {
//    
//}

#pragma mark - Setters & Getters
-(void)setAvatarURL:(NSString *)avatarURL {
    if (isEmptyString(avatarURL)) {
        _avatarView.avatarImage = [TKTImage imageNamed:@"MainLoverDefaultAvatar"];
    } else {
        _avatarView.avatarURL = avatarURL;
    }
}

-(NSString *)avatarURL {
    return _avatarView.avatarURL;
}

#pragma mark - Private
-(void)_initViews {
    self.image = [UIImage imageNamed:@"MapLoverAnnotationBackground"];
    TKTWidthReferenceSizeBegin {
        const CGFloat backgroundSize = TKTSize(80.0f);
        const CGFloat halfBackgroundSize = backgroundSize * 0.5f;
        const CGFloat avatarY =  TKTSize(15.5f);
        const CGFloat avatarSize = TKTSize(49.0f);
        
        self.imageView.size = CGSizeMake(backgroundSize, backgroundSize);
        self.imageView.contentMode = UIViewContentModeScaleAspectFit;
        self.centerOffset = CGPointMake(0, -halfBackgroundSize);
        
        _avatarView = TKTAvatarView.New;
        _avatarView.frame = CGRectMake(0.0f, avatarY, avatarSize, avatarSize);
        _avatarView.centerX = halfBackgroundSize;
        _avatarView.avatarSize = avatarSize;
        _avatarView.clickable = YES;
        _avatarView.contentMode = UIViewContentModeScaleAspectFit;
        
        TKTWeakSelf
        _avatarView.avatarDidClick = ^{
            TKTStrongSelf {
                const TKTEmptyCallback callback = self.avatarDidClick;
                if (callback) {
                    callback();
                }
            }
        };
        [self addSubview:_avatarView];
        
        self.imageView.layer.shadowColor = TKTCGColor(#000000, 0.3f);
        self.imageView.layer.shadowOffset = CGSizeMake(0, TKTSize(2.0f));
        self.imageView.layer.shadowOpacity = 1.0f;
        self.imageView.layer.shadowRadius = TKTSize(10.0f);
    } TKTWidthReferenceSizeEnd
    
}

@end
